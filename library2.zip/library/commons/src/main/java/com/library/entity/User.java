package com.library.entity;

import lombok.Data;

/**
 * @author: shg
 * @create: 2022-04-30 7:28 下午
 */
@Data
public class User {
    int uid;
    String name;
    String sex;
}
