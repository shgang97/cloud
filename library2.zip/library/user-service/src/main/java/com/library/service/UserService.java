package com.library.service;

import com.library.entity.User;

/**
 * @author: shg
 * @create: 2022-04-30 8:25 下午
 */
public interface UserService {
    User getUserById(int uid);
}
