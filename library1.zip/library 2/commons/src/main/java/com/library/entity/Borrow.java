package com.library.entity;

import lombok.Data;

/**
 * @author: shg
 * @create: 2022-04-30 8:58 下午
 */
@Data
public class Borrow {
    int id;
    int uid;
    int bid;
}
